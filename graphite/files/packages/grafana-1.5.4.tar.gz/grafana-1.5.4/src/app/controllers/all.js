define([
  './dash',
  './dashLoader',
  './row',
  './submenuCtrl',
  './pulldown',
  './search',
  './metricKeys',
  './graphiteTarget',
  './graphiteImport',
  './influxTargetCtrl',
  './playlistCtrl',
  './inspectCtrl',
], function () {});
