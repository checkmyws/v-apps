define([
  './alertSrv',
  './dashboard',
  './datasourceSrv',
  './filterSrv',
  './timer',
  './panelMove',
  './keyboardManager',
  './annotationsSrv',
  './playlistSrv',
  './unsavedChangesSrv',
],
function () {});