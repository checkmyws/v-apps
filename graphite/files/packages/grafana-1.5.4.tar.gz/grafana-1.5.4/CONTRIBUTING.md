If you have any idea for an improvement or found a bug do not hesitate to open an issue.
And if you have time clone this repo and submit a pull request and help me make Grafana the
kickass metrics & devops dashboard we all dream about!

Prerequisites:
 - Nodejs (for jshint & grunt & development server)

Clone repository:

    npm install
    grunt server (starts development web server in src folder)
    grunt (runs jshint and less -> css compilation)

Please remember to run grunt before doing pull request to verify that your code passes all the jshint validations.
